#include "BomberMan.h"

void AI(const Game *game, Operator op[PLAYER_NUM])
{
    //Demo
    //Get your group id.
    int id = game->grpid;
    int x, y;
    //Get your name.
    game->group[id].name;
    //Get your score.
    game->group[id].score;

    //Everyone has three players and their info is stored in
    //game->group[id].player[0,1,2]
    //For example player[0]
    game->group[id].player[0].group;        //group id
    game->group[id].player[0].player;       //player id
    game->group[id].player[0].life_value;   //life value
    game->group[id].player[0].bomb_num;     //number of bombs left
    game->group[id].player[0].pos;          //player's position (x, y)

    //Situation of the battle field.
    //Traverse the map.
    for(y = 1; y <= MAP_ROW; ++y) {
        for(x = 1; x <=MAP_COL; ++x) {
            Object obj = game->map[y][x]; 
            switch(obj.type) {
                case BLANK: 
                    //This obj is empty
                    break;
                case WOOD: 
                    //This obj is wood
                case STONE:
                	//This obj is stone
                    break;
                case HOME:  
                    //This obj is home
                    obj.home;
                    break;
                case BOMB:  
                    //This obj is bomb
                    obj.bomb;
                    break;
            }
        } 
    }
    //According to the info of map and players mentioned above, determine next move of your players, and set them in op.
    //For example, set player 0 UP, player 1 put bomb, player 2 keep still
    op[0] = UP;
    op[1] = PUT;
    op[2] = NOP;
    //For specific definition of structs, just check the BombMan.h
}
